// -------------------------
// ignore estas dos líneas:
#ifndef DISTANCIA
#define DISTANCIA
// ------------------------

#include <iostream>
#include <math.h>
#include "vector.h"


double veuclidea(vector , vector );

double vmanhattan(vector , vector );



// -------------------------
// ignore esta línea:
#endif
// ------------------------
