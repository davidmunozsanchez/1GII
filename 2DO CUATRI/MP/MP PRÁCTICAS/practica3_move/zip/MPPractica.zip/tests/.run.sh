touch tests//.timeout
CMD="   /home/davidms_83/Documentos/MP/PRACTICAS/practica3_move/dist/Debug/GNU-Linux/practica3_move  -l ES -r 100 -i data/OPEN_ERROR.data 1> tests//.out8 2>&1"
eval $CMD
rm tests//.timeout
