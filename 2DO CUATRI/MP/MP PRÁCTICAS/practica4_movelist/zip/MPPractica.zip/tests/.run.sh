touch tests//.timeout
CMD="   /home/davidms_83/Documentos/MP/PRACTICAS/practica4_movelist/dist/Debug/GNU-Linux/practica4_movelist   1> tests//.out11 2>&1"
eval $CMD
rm tests//.timeout
