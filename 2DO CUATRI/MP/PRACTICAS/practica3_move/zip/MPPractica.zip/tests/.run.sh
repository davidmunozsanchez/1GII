touch tests//.timeout
CMD="   /home/davidms_83/Documentos/MP/PRACTICAS/practica3_move/dist/Debug/GNU-Linux/practica3_move   1> tests//.out11 2>&1"
eval $CMD
rm tests//.timeout
