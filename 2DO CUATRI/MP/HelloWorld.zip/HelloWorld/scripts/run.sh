#!/bin/bash
java -jar dist/UGRStudentFX.jar $*
