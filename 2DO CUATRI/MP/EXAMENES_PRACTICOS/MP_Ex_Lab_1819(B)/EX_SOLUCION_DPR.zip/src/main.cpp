/**
 * @file main.cpp
 * @author Daniel Pérez Ruiz
 * @brief 
 * Universidad de Granada - DGIM
 * Metodología de la Programación 
 * Examen de laboratorio 2018-2019
 * Por favor, rellene las funciones que se indican.
 * Una vez ejecutado el programa y obtenidos los ficheros de salida,
 * ejecute la script validaFicheros.sh para comprobar que la salida es correcta
 * No olvide pasar valgrind.
*/
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <cstdlib>

using namespace std;

/**
 * @brief Función que analiza la IP del ordenador de prácticas y genera un número
 * entero asociado a ella
 * @return Un número entero obtenido a partir de la IP del ordenador de prácticas;
 */
int findIP();

/**
 * @brief Clase punto bidimensional
 */
class Punto {
public: 
    double _x, _y;};

/**
 * @brief Clase círculo
 */
class Circulo{
public: 
    Punto _centro; 
    double _radio;
    /**
     * @brief Constructor que inicializa el círculo dependiendo de la IP
     * del ordenador en la que se ejecute
     */
    Circulo();
    /**
     * Método que calcula si un punto está dentro del círculo o no
     * @param p El punto a calcular
     * @return @retval true si @a p está dentro del círulo, @retval false en otro caso
     */
    bool estaDentro(Punto p) const;
};

/**
@brief Imprime el contenido de un vector de Punto
@param v 	Vector de Punto
@param n	Número de elementos que contiene @a v
*/
void imprimirVector(Punto *, int n);

void saveFichero(string fichero, int numero_datos, Punto* Salida){
    ofstream fout;
    
    fout.open(fichero);
    if(fout){
        fout << numero_datos << endl;
        if(fout){
            for(int i=0; i<numero_datos; i++){
                fout << Salida[i]._x << " " << Salida[i]._y << endl;
            }
            if(!fout){
                cerr << "ERROR AL GUARDAR DATOS EN FICHERO [" << fichero << "]" << endl;
                exit(1);
            }
            else{
                cout << "SE HAN GUARDADO [" << numero_datos << "] PUNTOS CORRECTAMENTE EN EL FICHERO [" << fichero << "]" << endl;
            }
        }
        else{
            cerr << "ERROR EN EL FICHERO [" << fichero << "]" << endl;
            exit(1);
        }
        fout.close();
    }
    else{
        cerr << "ERROR: EL FICHERO [" << fichero << "] NO ES VALIDO" << endl;
        exit(1);
    }
}

int main()  {
    Circulo C;                      /// Cïrculo. Se inicializa automáticamente según la IP del ordenador
    Punto *Puntos=nullptr,          /// Vector de puntos leídos del fichero 
        *Dentro=nullptr,            /// Vector de puntos que están dentro del círculo
        *Fuera=nullptr;             /// Vector de puntos que están fuera del círculo
    int nPuntos=0,                  /// Número de elementos de Puntos[]
        nDentro=0,                  /// Número de elementos de Dentro[]
        nFuera=0;                   /// Número de elementos de Fuera[]
    
    int j=0, l=0;
    ifstream fPuntos;               /// Fichero de entrada
    string sPuntos="data/datos1.dat",   /// Nombre del fichero de entrada
           sDentro="data/salida_"+to_string(findIP()%10)+".in",  /// Fichero de salida para Dentro[]
           sFuera="data/salida_"+to_string(findIP()%10)+".out";  /// Fichero de salida para Fuera []   

    /// Examen: Leer fichero de datos
    fPuntos.open(sPuntos);
    if(fPuntos){
        fPuntos >> nPuntos;
        if(nPuntos > 0){
            Puntos = new Punto [nPuntos];
                
            for(int i=0; i<nPuntos;i++){
                fPuntos >> Puntos[i]._x;
                fPuntos >> Puntos[i]._y;
            }
            
            if(!fPuntos){
                cerr << "ERROR AL LEER EL ARCHIVO [" << sPuntos << "]" << endl;
                
                delete [] Puntos;
                Puntos = nullptr;
                exit(1);
            }
            else{
                cout << "SE HAN LEIDO [" << nPuntos << "] PUNTOS CORRECTAMENTE DEL FICHERO [" << sPuntos << "]" << endl;
            }
            
        }
        else{
            cerr << "NUMERO DE DATOS [" << nPuntos << "] NO VALIDO" << endl;
            exit(1);
        }
        fPuntos.close();
    }
    else{
        cerr << "EL FICHERO [" << sPuntos << "] NO ES VALIDO" << endl;
        exit(1);
    }
        

    /// Examen: Imprimir los datos leídos
    cout << "Datos leídos"<<endl;
    imprimirVector(Puntos, nPuntos);

    /// Examen: Calcular resultado
    for(int i=0; i<nPuntos; i++){
        if(C.estaDentro(Puntos[i])){
            nDentro++;
        }
        else{nFuera++;}
    }
    
    if(nFuera > 0)
        Fuera = new Punto [nFuera];
    
    if(nDentro > 0)
        Dentro = new Punto [nDentro];
    
    for(int i=0; i<nPuntos; i++){
        if(C.estaDentro(Puntos[i])){
            Dentro[j] = Puntos[i];
            j++;
        }
        else{
            Fuera[l] = Puntos[i];
            l++;
        }
    }
    
    /// Examen: Mostrar resultado
    cout << "Quedan fuera"<<endl;
    imprimirVector(Fuera, nFuera);

    cout << "Quedan dentro"<<endl;
    imprimirVector(Dentro, nDentro);

    /// Examen: Guardar resultado en disco
    saveFichero(sDentro,nDentro,Dentro);
    saveFichero(sFuera,nFuera,Fuera);
    
    /// Examen: Terminación del programa
    if(Puntos != nullptr)
        delete [] Puntos;
    
    if(Dentro != nullptr)
        delete [] Dentro;
    
    if(Fuera != nullptr)
        delete [] Fuera;
}

void imprimirVector(Punto *v, int n)  {
    if (n>0 && v != nullptr)  {
        cout << n << " elementos" << endl;
        for (int i=0; i<n; i++)
                cout << "["<<i<<"] = " << v[i]._x<<"-" << v[i]._y << (i%8==7? "\n" : "\t");
        cout << endl;
    }
    else
        cerr << "ERROR el vector está vacío"<<endl;
}

int findIP()  {
    ifstream f;
    string name;
    f.open("/etc/hostname");
    f >> name;
    f.close();
    return name[name.length()-1]-'0';
}

Circulo::Circulo() {
    int IP = findIP();
    srand(IP%10);
    _radio = rand() % 8;
    _centro._x = rand() % 20;
    _centro._y = rand() % 20;
    cout << "Círculo ("<<_centro._x<<","<<_centro._y<<")-"<<_radio<<endl;
}

bool Circulo::estaDentro(Punto p)  const{
    return sqrt(pow(p._x-_centro._x,2)+pow(p._y-_centro._y,2))<=_radio;
}
