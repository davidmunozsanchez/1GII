/*	Un numero entero se dice torn si queda dividido en dos partes y el cuadrado de la suma de ambas
	partes es igual a dicho entero. El siguiente programa nos dira si un entero introducido es 
	desgarrable
*/

#include <iostream>
#include <cmath>
	
using namespace std;

int main(){
	// Declaracion de variables
	int numero, num_izq, num_dcha = 0;
	int cuadrado = 0, potencia10 = 10;
	bool es_desgarrable = false;
    
	cout << "\nInserta un numero: ";
	cin >> numero;
	
    num_izq = numero;
    
    // Mientras que el numero sea mayor que 9 y la condicion de desgarrable falsa
    while ( num_izq > 9 && !es_desgarrable){
    	// Recorremos el numero por la izquierda y por la derecha
        num_izq = numero / potencia10;
        num_dcha = numero % potencia10;
        cuadrado = (num_izq + num_dcha) * (num_izq + num_dcha);
        potencia10 = potencia10 * 10;
        es_desgarrable = (numero == cuadrado);
    }
	
	// Mostramos en pantalla dependiendo del resultado
    if ( es_desgarrable )
		cout << "El numero " << numero << " es desgarrable";
	else
		cout << "\nEl numero " << numero << " no es desgarrable\n";
}
