/*	Programa que pide al usuario introducir una mayuscula y en caso de que no lo sea
	se le pide otra vez, usando una estructura do while
*/

#include <iostream>

using namespace std;

int main (){
	// Declaracion de variables y constantes
	const int letra_a = 'A';
	const int letra_z = 'Z';
	char mayus;
	
	// Leemos si la letra esta entre A y Z	
	do{
		cout << "Introduce una letra mayuscula: ";
		cin  >> mayus;
	} while (mayus < letra_a || mayus > letra_z);
}
