/*	Programa para calcular el total de dinero obtenido en un a�o
	dados el capital y el interes
	Necesita: un capital y un interes (el interes ser� un valor real entre 0 y 100)
	Calcula: el total de dinero obtenido en un a�o siguiendo la 
	formula total = capital + capital*(interes/100)
*/

#include <iostream>	// Inclusion de los recursos de E/S

using namespace std;

int main(){	
	// Declaracion de variables			
	double capital;   	
	double interes;	
	double total; 
	int anio = 0;
	double capital_x2;
	double capital_acumulado;
	
	// Introducimos los datos
	cout << "Introduzca el capital: " ;	
	cin  >> capital ;
	cout << "Introduzca el interes: " ;
	cin  >> interes ;
	
	capital_acumulado = capital;
	capital_x2 = capital * 2;
	
	// Mientras que el capital que se acumula cada anio se menor o igual al doble
	while (capital_acumulado <= capital_x2){
		
		capital_acumulado = capital_acumulado + capital_acumulado * (interes / 100);
		
		cout << "El capital acumulado en el anio " << anio << " es " << capital_acumulado << "\n";
		
		anio ++;
	}									
																
}
