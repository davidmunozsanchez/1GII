/*	Programa para calcular el factorial de un numero y la potencia de otro */

#include <iostream>

using namespace std;

int main(){
	// Declaracion de variables
	int exponente, num_fact;
	double base;
	int i, j;
	double potencia = 1;
	int factorial_fin = 1;
	
	// Introduccion de datos
	cout << "Introduce el numero del que quiere calcular el factorial: ";
	cin  >> num_fact;
	cout << "Introduce la base y el exponenete para realizar la potencia (separados por espacios): ";
	cin  >> base >> exponente;
	
	// Calculamos la potencia
	for (i = 1; i <= exponente; i++){
		potencia = base * potencia;
	}
	
	cout << "La potencia con base " << base << " y exponente " << exponente << " es " << potencia;
	
	// Calculamos el factorial
	for (j = 1; j <= num_fact; j++) {
		factorial_fin = factorial_fin * j;
		
	}
	
	cout << "\n\nEl factorial de " << num_fact << " es " << factorial_fin;
}
