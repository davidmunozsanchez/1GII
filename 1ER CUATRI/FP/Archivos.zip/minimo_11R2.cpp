#include <iostream>

using namespace std;

int main(){
	// Declaracion de variables
	int dato, menor;
	int contador = 0;
	bool es_menor;
	
	cout << "Introduce los numeros enteros que desee, separados por espacios: ";
	cin >> menor;
	
	// Previamente incrementamos el contador si es distinta de cero la primera entrada
	if ( menor != 0 )
		contador++;
	else
		dato = 0;
	
	// Mientras dato sea distinto de 0
	while ( dato != 0 ) {
		cin >> dato;
		
		if ( dato != 0 ) {
			contador++;
			
			if ( dato < menor )
				menor = dato;
		}
	}
	
	cout << "Ha introducido " << contador << " entero(s)";
	
	if ( contador > 0 )
		cout << "\n\nEl menor de los enteros introducidos es " << menor;
}
