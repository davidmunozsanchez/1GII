/*	Programa para imprimir en pantalla todos los divisores propios de un entero positivo,
	usando bucles de distintos tipos
*/
#include <iostream>

using namespace std;

int main(){
	// Declaracion de variables
	int entero;
	int i;
	bool divide;
	
	// Introducimos un entero que no sea ni negativo ni cero
	do{
		cout << "Introduce el numero entero positivo para buscar sus divisores propios: ";
		cin  >> entero;
	} while (entero <= 0);
	
	// Comprobamos 1 a 1 si los numeros de 1 a entero son divisores
	for (i = 1; i <= entero; i++){
		divide = entero % i == 0;
		
		if (divide)
			cout << i << "\n";
	}
}
